给一个sidewalk（1m），随机落下雨滴，每一个雨滴可以打湿一个固定的长度（1cm）。. 1point 3acres 璁哄潧
    给一个getRaindrop() ，每调用一次就自动生成一个雨滴，位置范围在-0.01到1.01。. 鐣欏鐢宠璁哄潧-涓€浜╀笁鍒嗗湴

    问多久可以把整个sidewalk打湿。


    我觉得本质是insert interval & merge interval, 但是要考虑的地方特别多，整个写完代码量应该也不少。