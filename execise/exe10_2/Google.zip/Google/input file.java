 1. input file，file中是一堆string，要求除去重复行并输出，A：map存每行，重复就skip；. more info on 1point3acres.com
        follow up：file非常大怎么办， A： trie树存
    2. 如果一个map的size非常小，怎么implement，我用了链表，写得不太对；