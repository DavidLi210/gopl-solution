unqiue path
    follow up是中间必须经过点（x，y） 两次计算结果相乘b