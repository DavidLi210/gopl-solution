时间复杂度m*n*p
    给你一个matrix, 先问你矩阵乘法的complexity。 然后如果矩阵是band matrix该怎么办， 怎么计算upper-bandwidth and lower-bandwidth.  主要讨论都是计算方法， 和计算复杂度之类的。 最后的follow up是如果矩阵很大， 读不进来， 怎么就算bandwidth。 答： 一行一行读来计算。（感觉这一面还行， 面试官人也很好）
311. Sparse Matrix Multiplication