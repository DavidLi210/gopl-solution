给一个binary tree，每个节点是一个char，每个leave to root path构成一个字符串，输出其中最小的一个。

    后序遍历，找到最小与根结合。